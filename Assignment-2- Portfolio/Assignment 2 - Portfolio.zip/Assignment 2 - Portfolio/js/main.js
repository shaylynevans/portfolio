$(".menu-open").click(function() {
	$('body').addClass('open')
});

$(".menu-close").click(function() {
	$('body').removeClass('open')
});